# Import all histograms
import selection_0
import selection_1
import selection_2
import selection_3
import selection_4
import selection_5
import selection_6
import selection_7
import selection_8
import selection_9
import selection_10

# Producing each histograms
print "BEGIN-STAMP"
print "- Producing histo selection_0..."
selection_0.selection_0()
print "- Producing histo selection_1..."
selection_1.selection_1()
print "- Producing histo selection_2..."
selection_2.selection_2()
print "- Producing histo selection_3..."
selection_3.selection_3()
print "- Producing histo selection_4..."
selection_4.selection_4()
print "- Producing histo selection_5..."
selection_5.selection_5()
print "- Producing histo selection_6..."
selection_6.selection_6()
print "- Producing histo selection_7..."
selection_7.selection_7()
print "- Producing histo selection_8..."
selection_8.selection_8()
print "- Producing histo selection_9..."
selection_9.selection_9()
print "- Producing histo selection_10..."
selection_10.selection_10()
print "END-STAMP"
